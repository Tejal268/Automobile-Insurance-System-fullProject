import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  standalone: false,
  templateUrl: './aboutus.html',
  styleUrl: './aboutus.css'
})
export class Aboutus {

}
