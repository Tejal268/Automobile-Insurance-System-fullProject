import { Component } from '@angular/core';

@Component({
  selector: 'app-officerlogin',
  standalone: false,
  templateUrl: './officerlogin.html',
  styleUrl: './officerlogin.css'
})
export class Officerlogin {

}