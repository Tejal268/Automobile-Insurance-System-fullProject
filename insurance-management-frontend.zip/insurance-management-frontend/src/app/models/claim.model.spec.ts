import { ClaimModel } from './claim.model';

describe('ClaimModel', () => {
  it('should create an instance', () => {
    expect(new ClaimModel()).toBeTruthy();
  });
});
