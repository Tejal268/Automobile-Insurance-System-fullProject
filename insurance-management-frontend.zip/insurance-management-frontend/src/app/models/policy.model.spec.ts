import { PolicyModel } from './policy.model';

describe('PolicyModel', () => {
  it('should create an instance', () => {
    expect(new PolicyModel()).toBeTruthy();
  });
});
