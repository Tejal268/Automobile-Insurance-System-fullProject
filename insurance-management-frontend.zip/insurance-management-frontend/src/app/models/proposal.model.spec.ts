import { ProposalModel } from './proposal.model';

describe('ProposalModel', () => {
  it('should create an instance', () => {
    expect(new ProposalModel()).toBeTruthy();
  });
});
