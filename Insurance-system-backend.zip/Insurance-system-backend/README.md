# Automobile-Insurance-System (Backend)

Tech stack used - Spring boot java


Below some links:

> 🔗 [PPT Presentation](https://docs.google.com/presentation/d/1J0rjwsVoFBF8ZsahNZUNFh_DQk0dY2fV/edit?usp=sharing&ouid=117896069227246961666&rtpof=true&sd=true)


> 🔗 [Project swagger- word Doc](https://drive.google.com/file/d/1HWTGe_OoqAGLNnCnPHX6yu8FjS5YaZyn/view?usp=sharing)


> 🔗 [Demo video](https://drive.google.com/file/d/1Pvc8mYmTyKionIG9haTFqLoXDZI3N68b/view?usp=sharing)


Thank you

