package com.example.demo.Exceptions;

public class UserNotFound extends RuntimeException{

	public UserNotFound(String message) {
		super(message);
		
	}
	 
}
