package com.example.demo.Entity;

public enum ClaimStatus {
    PENDING,
    APPROVED,
    REJECTED
}
