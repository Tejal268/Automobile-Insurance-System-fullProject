package com.example.demo.Entity;
public enum ProposalStatus {
    SUBMITTED, PENDING,PENDING_DOCUMENTS, APPROVED, REJECTED, QUOTE_GENERATED, ACTIVE, EXPIRED,PAID
}
